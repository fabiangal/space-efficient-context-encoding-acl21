This dataset version is post processed by us, but all credits go to facebookresearch.
The original dataset can be found here: https://github.com/facebookresearch/opendialkg

If you use this data, make sure to cite them correctly:

@InProceedings{Moon2019opendialkg,
author = {Seungwhan Moon and Pararth Shah and Anuj Kumar and Rajen Subba},
title = {OpenDialKG: Explainable Conversational Reasoning with Attention-based Walks over Knowledge Graphs},
booktitle = {Proceedings of the 57th Annual Meeting of the Association for Computational Linguistics},
month = {July},
year = {2019},
}


